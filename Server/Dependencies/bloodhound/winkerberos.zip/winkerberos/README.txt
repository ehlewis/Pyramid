https://github.com/mongodb/winkerberos/tree/master

Built for cp312-win_amd64 from version 0.12.0

